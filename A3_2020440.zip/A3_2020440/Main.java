import java.util.*;

// KARTIK JAIN  2020440  AP ASSIGNMENT_3  SNAKES AND LADDERS PROBLEM

class Floors{
    private int points = 0;
    private int floorno = -1;
    
    protected int points(){
        return this.points;
    }
    protected int floorno(){
        return this.floorno;
    }
    protected void spoints(int x){
        this.points = x;
    }
    protected void sfloorno(int y){
        this.floorno = y;
    }
    public int total_points(Player p){
        points = 1;
        p.setpoints(points);
        return points;
    }
    public int floor_no(Player p){
        floorno = 1;
        p.setfloor(floorno);
        return floorno;
    }
}

class empty_floor extends Floors{
    public int floor_no(Player p, int d){
        int floorno = d;
        p.setfloor(floorno);
        return floorno;
    }
}
class normal_snake extends Floors{
    @Override
    public int total_points(Player p){
        spoints(-2);
        p.setpoints(points());
        return points();
    }
    @Override
    public int floor_no(Player p){
        sfloorno(-4);
        p.setfloor(floorno());
        return floorno();
    }
}
class king_cobra extends Floors{
    @Override
    public int total_points(Player p){
        spoints(-4) ;
        p.setpoints(points());
        return points();
    }
    @Override
    public int floor_no(Player p){
        sfloorno(-8);
        p.setfloor(floorno());
        return floorno();
    }
}
class ladder extends Floors{
    @Override
    public int total_points(Player p){
        spoints(2);
        p.setpoints(points());
        return points();
    }
    @Override
    public int floor_no(Player p){
        sfloorno(4);
        p.setfloor(floorno());
        return floorno();
    }
}
class elevator extends Floors{
    @Override
    public int total_points(Player p){
        spoints(4);
        p.setpoints(points());
        return points();
    }
    @Override
    public int floor_no(Player p){
        sfloorno(8);
        p.setfloor(floorno());
        return floorno();
    }
}

class Dice{
    static Random rand = new Random();
    private final int numFaces = 2;
    private int faceValue;
    // Rolls the dice
    public void roll() {
        int curr_faceValue = 1 + rand.nextInt(numFaces);
        setFaceValue(curr_faceValue);
    }
    // Face value setter/mutator.
    private void setFaceValue (int value) {
        if (value <= numFaces){
            faceValue = value;
        }
    }
    // Face value getter/setter.
    public int getFaceValue() {
        return faceValue;
    }
    
}

class Player{
    private String name;
    private int floor = -1;
    private int points;
    public void setName(String na){
        this.name = na;
    }
    public void setfloor(int f){
        this.floor = this.floor + f ;
    }
    public void setpoints(int p){
        this.points = this.points + p ;
    }
    public String getname(){
        return this.name;
    }
    public int getfloor(){
        return this.floor;
    }
    public int getpoints(){
        return this.points;
    }
    public int roll_dice(Dice d){
        d.roll();
        int a = d.getFaceValue();
        return a;
    }
    public void displayinfo(String floorname){
        System.out.println("Player position Floor-" + floor);
        System.out.println(name +" has reached an " + floorname + " floor");
        System.out.println("Total points " + points);
    }

}

public class Main{
    public static void floor_no(Floors f0, Player p0){
        f0.floor_no(p0);
    }
    public static void total_points(Floors f0, Player p0){
        f0.total_points(p0);
    }
    public static void main(String[] args){
        Scanner s = new Scanner(System.in);
        Dice d = new Dice();
        Player p1 = new Player();
        empty_floor emf = new empty_floor();
        Floors sf = new normal_snake();
        Floors kcf = new king_cobra();
        Floors lf = new ladder();
        Floors elf = new elevator();

        System.out.print("Enter the player name and hit enter: ");
        String name = s.nextLine();
        System.out.println();
        p1.setName(name);
        System.out.println("The game setup is ready");
        
        int var = 0;
        while(var != 1){
            System.out.print("Hit enter to roll the dice");
            s.nextLine();
            System.out.println();
            int dval = p1.roll_dice(d);
            System.out.println("Dice gave " + dval);
            if(d.getFaceValue() == 1){
                total_points(emf,p1);
                floor_no(emf,p1);
                p1.displayinfo("Empty");
                var = var + 1;
                System.out.println();
            }
            else{
                System.out.println("Game cannot start until you get 1");
                System.out.println();
            }
        }

        while(p1.getfloor() != 13){
            System.out.print("Hit enter to roll the dice");
            s.nextLine();
            System.out.println();
            int dval = p1.roll_dice(d);
            System.out.println("Dice gave " + dval);
            int fc = dval + p1.getfloor();
            
            if(fc == 1|| fc == 3||fc == 4 || fc == 6 || fc == 7 || fc == 9 || fc == 10 || fc == 12){
                //p1.setfloor(fc);
                total_points(emf,p1);
                emf.floor_no(p1, dval);
                p1.displayinfo("Empty");
                System.out.println();
            }
            
            else if(fc == 2){
                p1.setfloor(dval);
                total_points(elf,p1);
                p1.displayinfo("Elevator");
                floor_no(elf,p1);
                total_points(emf,p1);
                p1.displayinfo("Empty");
                System.out.println();
            }

            else if(fc == 5){
                p1.setfloor(dval);
                total_points(sf,p1);
                p1.displayinfo("Normal Snake");
                floor_no(sf,p1);
                total_points(emf,p1);
                p1.displayinfo("Empty");
                System.out.println();
            }

            else if(fc == 8){
                p1.setfloor(dval);
                total_points(lf,p1);
                p1.displayinfo("Ladder");
                floor_no(lf,p1);
                total_points(emf,p1);
                p1.displayinfo("Empty");
                System.out.println();
            }

            else if(fc == 11){
                p1.setfloor(dval);
                total_points(kcf,p1);
                p1.displayinfo("King Cobra Snake");
                floor_no(kcf,p1);
                total_points(emf,p1);
                p1.displayinfo("Empty");
                System.out.println();
            }

            else if(fc == 13){
                total_points(emf,p1);
                emf.floor_no(p1,dval);
                p1.displayinfo("Empty");
                System.out.println("Game Over");
                String nm = p1.getname();
                int po = p1.getpoints();
                System.out.println(nm + " accumulated " + po + " points");
                System.out.println();
            }

            else if(fc == 14){
                System.out.println("Player cannot move");
                System.out.println();
            }
        }
       s.close(); 
    }
}
