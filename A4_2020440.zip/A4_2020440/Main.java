import java.util.*;

class inputInvalidexception extends Exception { 
    public inputInvalidexception(String s) {
        super(s);
    }
}

class Toys implements Cloneable{
    private String name;
    public Toys(String s){
        this.name = s;
    }
    public String getname(){
        return name;
    }
    
    public Toys clone(int i,ArrayList<Toys> t){
        try{
            Toys copy = (Toys) t.get(i).clone();
            return copy;
        }
        catch(CloneNotSupportedException e){
            return null;
        }
    }
}

class Calculator<A> {
    private A n1 , n2;
    public Calculator(A x, A y) {
        try{
            if(((x instanceof Integer) && (y instanceof Integer)) || ((x instanceof String) && (y instanceof String))){
                n1 = x;
                n2 = y;
            }
            else{
                throw new IllegalArgumentException("Invalid Datatype");
            }
        }
        catch(IllegalArgumentException e){
            System.out.println(e.getMessage());
        }
    }
    public String str_add(){
        return ((String) n1 + (String) n2);
    }
    public int int_div(){
        return ((int)n1/(int)n2);
    }
}

class Player{
    Scanner s = new Scanner(System.in);
    Random ran = new Random();
    
    private ArrayList<String> toyswon = new ArrayList<String>();
    private ArrayList<Toys> bucket = new ArrayList<Toys>();
    
    public ArrayList<String> getToyswon(){
        return toyswon;
    }
    public int hop(){
        int r = ran.nextInt(30);
        return r;
    }

    public void gettoy(Toys t,int h,ArrayList<Toys> tile){
        if(h>1){
            Toys cl = t.clone(h-1,tile);
            bucket.add(cl);
            toyswon.add(cl.getname());
            System.out.println("You won a "+cl.getname()+" soft toy");
        }
        else{
            Toys cl = t.clone(0,tile);
            bucket.add(cl);
            toyswon.add(cl.getname());
            System.out.println("You won a "+cl.getname()+" soft toy");
        }
        
    }
    public boolean checkint(int n, int m, int ans){
        Calculator<Integer> c = new Calculator<Integer>(n,m);
        int res = c.int_div();
        if(ans == res){
            System.out.println("Correct Answer");
            return true;
        }
        return false;
    }
    public String randomString(){
        StringBuilder stb = new StringBuilder();
        String big = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "abcdefghijklmnopqrstuvwxyz";
        for(int i = 0; i < 4; i++) {
            int ind = ran.nextInt(big.length());
            char rch = big.charAt(ind);
            stb.append(rch);
        }
        String randomString = stb.toString();
        return randomString;
    }
    public boolean checkstr(){
        String s1 = randomString();
        String s2 = randomString();
        Calculator<String> c = new Calculator<String>(s1,s2);
        String res = c.str_add();
        s.nextLine();
        System.out.println("Calculate the concatenation of strings "+s1+ " and "+s2);
        String inp = s.nextLine();
        if(inp.equals(res)){
            System.out.println("Correct Answer");
            return true;
        }
        return false;
    }
}

public class Main{
    public static void main(String[] args) throws inputInvalidexception, InputMismatchException{
        
        Scanner sc = new Scanner(System.in);
        Random ran = new Random();
        ArrayList<Toys> tiles = new ArrayList<Toys>();
        tiles.add(new Toys("Bear"));
        tiles.add(new Toys("Duck"));
        tiles.add(new Toys("Dog"));
        tiles.add(new Toys("Mickey"));
        tiles.add(new Toys("Jerry"));
        tiles.add(new Toys("Tom"));
        tiles.add(new Toys("Lion"));
        tiles.add(new Toys("Tiger"));
        tiles.add(new Toys("Cat"));
        tiles.add(new Toys("Monkey"));
        tiles.add(new Toys("Elephant"));
        tiles.add(new Toys("Scooby"));
        tiles.add(new Toys("Sunflower"));
        tiles.add(new Toys("Minnie"));
        tiles.add(new Toys("Hulk"));
        tiles.add(new Toys("Ironman"));
        tiles.add(new Toys("Spiderman"));
        tiles.add(new Toys("Spider"));
        tiles.add(new Toys("Giraffe"));
        tiles.add(new Toys("Minion"));
        
        String moveno[] = {"Hit enter for your first hop","Hit enter for your second hop","Hit enter for your third hop","Hit enter for your fourth hop","Hit enter for your fifth hop"};
        Toys t = new Toys("T1");
        Player p = new Player();

        System.out.print("Hit enter to initialize the game");
        sc.nextLine();
        System.out.println("Game is ready");
        System.out.println("");
        for(int i=0; i<5; i++){
            System.out.print(moveno[i]);
            sc.nextLine();
            int hop = p.hop();
            if(hop <= 20){
                if(hop % 2 != 0){
                    boolean whileloop = false;
                    while(!whileloop){
                        System.out.println("You landed on tile "+ hop);
                        System.out.println("Question answer round. Integer or Strings?");
                        String inp = sc.nextLine();
                        System.out.print("Hit enter to Confirm");
                        sc.nextLine();
                        try{
                            if(inp.equals("Integer") || inp.equals("integer")){
                                whileloop = true;
                                boolean w1 = false;
                                int n = ran.nextInt(20000);
                                int m = ran.nextInt(n);
                                if(m == 0){
                                    m = m+1;
                                }
                                
                                while(!w1){
                                    try{
                                        System.out.println("Calculate the result of "+n+ " divided by "+m);
                                        int ans = sc.nextInt();
                                        sc.nextLine();
                                        if(p.checkint(n,m,ans)){    
                                            p.gettoy(t,hop,tiles);
                                            w1 = true;
                                        }
                                        else if(!p.checkint(n,m,ans)){
                                            w1 = true;
                                            System.out.println("Incorrect answer\nYou did not win any soft toy");
                                        }
                                    }catch(InputMismatchException e){
                                        System.out.println("Invalid Input Datatype");
                                        sc.nextLine();
                                    }
                                }    
                            }
                            else if(inp.equals("Strings") || inp.equals("strings") || inp.equals("String") || inp.equals("string")){
                                if(p.checkstr()){ 
                                    p.gettoy(t,hop,tiles);
                                }
                                else{
                                    System.out.println("Incorrect answer\nYou did not win any soft toy");
                                }
                                whileloop = true;
                            }
                            else{
                                throw new inputInvalidexception("Wrong Input!");
                            }
                        }
                        catch(inputInvalidexception e){
                            System.out.println(e.getMessage());
                        }
                    }
                }
                else{
                    System.out.println("You landed on tile "+ hop);
                    p.gettoy(t,hop,tiles);
                }
            }
            else{
                System.out.println("You are too energetic and zoomed past all the tiles. Muddy Puddle Splash!");
            }
            System.out.println("");
        }
        System.out.println("Game Over\nSoft toys won by you are:");
        for(int i=0; i<p.getToyswon().size(); i++){
            System.out.print(p.getToyswon().get(i)+ ", ");
        }
        sc.close();
    }
}
